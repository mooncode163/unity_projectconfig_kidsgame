python $(dirname $0)/unity_realtime_log.py $@
