#!/usr/bin/python
# coding=utf-8
import sys
import zipfile
import shutil
import os
import os.path 

# os
IOS = "ios"
ANDROID = "android"
WIN = "win"

# channel
XIAOMI = "xiaomi"
HUAWEI = "huawei"
TAPTAP = "taptap"
APPSTORE = "appstore"
GP = "gp"

# share
WEIXIN = "weixin"
WEIXINFRIEND = "weixinfriend"
WEIBO = "weibo"
QQ = "qq"
QQZONE = "qqzone"

# ad
ADVIEW = "adview"
GDT = "gdt"
UNITY = "unity"
ADMOB = "admob"
VUNGLE = "vungle"
MOBVISTA = "mobvista"


# appstore 账号
APPSTORE_USER = "chyfemail163@163.com"
APPSTORE_PASSWORD = "uyok-ghdh-wzvc-vrcf"